clear
clc
close
%% Connecting the COM Server => Open a new Vissim Window:

feature('COM_SafeArraySingleDim', 1); % Matlab should only pass one-dimensional array to COM

Vissim = actxserver('Vissim.Vissim');
% If you have installed multiple Vissim Versions, you can open a specific Vissim version adding the version number
% Vissim = actxserver('Vissim.Vissim.10'); % Vissim 10
% Vissim = actxserver('Vissim.Vissim.20'); % Vissim 2020
Path_of_COM_Basic_Commands_network = cd; %'E:\OneDrive - kaist.ac.kr\KAIST_TOPS\Study\2_prj_study\VISSIM';

% Load a Vissim Network:
Filename                = fullfile(Path_of_COM_Basic_Commands_network, 'Matlab_simul.inpx');
flag_read_additionally  = false; % you can read network(elements) additionally, in this case set "flag_read_additionally" to true
Vissim.LoadNet(Filename, flag_read_additionally);

%% Set link environmennt
% Read Link Name:

Link_number = 1;
Name_of_Link = get(Vissim.Net.Links.ItemByKey(Link_number), 'AttValue', 'Name');
% Name_of_Link = Vissim.Net.Links.ItemByKey(Link_number).AttValue('Name'); % alternative (using the method "AttValue")
disp(['Name of Link(',num2str(Link_number),'):',32,Name_of_Link]) % char(32) is whitespace

% Set Link Name:
new_Name_of_Link = 'Study Area';

set(Vissim.Net.Links.ItemByKey(Link_number), 'AttValue', 'Name', new_Name_of_Link);
set(Vissim.Net.Links.ItemByKey(Link_number), 'AttValue','BehaviorType',1);
% 1: Urban (motorized), 2: Right-side rule (motorized), 3: Freeway (free lane selection)
% 4: Footpath (no interaction), 5: Cycle-Track (free overtaking)
% set(Vissim.Net.Links.ItemByKey(Link_number), 'AttValue', , 1);

%% Set vehicle composition:
Veh_composition_number = 1;
Rel_Flows = Vissim.Net.VehicleCompositions.ItemByKey(Veh_composition_number).VehCompRelFlows.GetAll;
set(Rel_Flows{1}, 'AttValue', 'DesSpeedDistr',  120); % Changing the vehicle type
set(Rel_Flows{2}, 'AttValue', 'DesSpeedDistr',  100); % Changing the desired speed distribution

%% Reduced Speed Area setting
RSA = Vissim.Net.ReducedSpeedAreas.GetAll;
set(RSA{1}, 'AttValue','DesSpeedDistr(10)',30);
set(RSA{2}, 'AttValue','DesSpeedDistr(10)',30);
set(RSA{1}, 'AttValue','DesSpeedDistr(20)',25);
set(RSA{2}, 'AttValue','DesSpeedDistr(20)',25);
set(RSA{1}, 'AttValue','DesSpeedDistr(30)',20);
set(RSA{2}, 'AttValue','DesSpeedDistr(30)',20);

set(RSA{3}, 'AttValue','DesSpeedDistr(10)',30);
set(RSA{4}, 'AttValue','DesSpeedDistr(10)',30);
set(RSA{3}, 'AttValue','DesSpeedDistr(20)',25);
set(RSA{4}, 'AttValue','DesSpeedDistr(20)',25);
set(RSA{3}, 'AttValue','DesSpeedDistr(30)',20);
set(RSA{4}, 'AttValue','DesSpeedDistr(30)',20);

%%
% Set vehicle input:
% VI_number   = 1; % VI = Vehicle Input
% new_volume  = 150; % vehicles per hour
Total_flow = 7200;%3000;
set(Vissim.Net.VehicleInputs.ItemByKey(1), 'AttValue', 'Volume(1)', Total_flow*0.7); %300
set(Vissim.Net.VehicleInputs.ItemByKey(2), 'AttValue', 'Volume(1)', Total_flow*0.06); %100
set(Vissim.Net.VehicleInputs.ItemByKey(3), 'AttValue', 'Volume(1)', Total_flow*0.03);  %50 
set(Vissim.Net.VehicleInputs.ItemByKey(4), 'AttValue', 'Volume(1)', Total_flow*0.21); %500
% 'Volume(1)' means the first defined time interval
% Hint: The Volumes of following intervals Volume(i) i = 2...n can only be
% edited, if continuous is deactivated: (otherwise error: "AttValue failed: Object 2: Attribute Volume (300) is no subject to changes.")

%% Parameter vectors
Np = 16; %4; % Prediction horizon
regen_eff = 0.3; % The regenerative efficiency of EV
% buffer = 1;      % The buffer size of speed control
resolution = 1;

Pred_speds = zeros(Np*resolution+1,8);
Opt_speds = zeros(Np*resolution, 1);

delta_t = 1/resolution;          % simulation time in a single step
% Load parameter values
map = readtable('./QGIS/StudyArea_SlopeMap.csv'); % degree in a meter
degmap = table2array(map); % Create the degree map about distance

hist_pred_i = [];
hist_opt_i = [];

hist_pred_v = [];
hist_opt_v = [];

hist_pred_a = [];
hist_opt_a = [];

hist_pred_dist = [];
hist_opt_dist = [];

hist_pred_moteff = [];
hist_opt_moteff = [];

hist_up_v = [];
hist_do_v = [];

hist_up_a = [];
hist_do_a = [];

hist_vio_v = [];
hist_vio_a = [];
%% ========================================================================
% Simulation
%==========================================================================
% Chose Random Seed
Vissim.Simulation.Stop
Random_Seed = 42;
set(Vissim.Simulation, 'AttValue', 'RandSeed', Random_Seed);
set(Vissim.Simulation, 'AttValue', 'SimSpeed', 10);
set(Vissim.Simulation, 'AttValue', 'SimRes',resolution);
% Initial Setting for simulation
Simul_steps = 400;   % 100 ->                   
init = 1;
while(init < Simul_steps) %0402
    Vissim.Simulation.RunSingleStep;
    init = init + 1;            
end

All_Vehicles = Vissim.Net.Vehicles.GetAll; % 0402
target_num = 1;        % target number of the test vehicle
% target vehicle selection 
while(true)
    Get_ll = get(All_Vehicles{target_num}, 'AttValue', 'Lane');
    Get_link = extractBefore(Get_ll,'-');
    if(Get_link == '3')
        Target = target_num;
        break
    else
        target_num = target_num + 1;
    end
end

st_link = extractBefore('1-1','-'); % 0402
while(true) %init < Simul_steps) 0402
%     Vissim.Simulation.RunSingleStep;
%     init = init + 1;          0402
    Get_ll = get(All_Vehicles{target_num}, 'AttValue', 'Lane');
    Get_link = extractBefore(Get_ll,'-');
    if(Get_link == st_link)
        break
    else
        Vissim.Simulation.RunSingleStep;
        init = init + 1;
    end
end

Simul_steps = init;
Fixed_steps = init;
target_veh = zeros(4,1);

time_set = 200*resolution*1; %500;  
% keep_target = get(All_Vehicles{target_num}, 'AttValue', 'Pos');
%%
while(init < Fixed_steps+Np*time_set)  % 300 -> 1minutes   
    %% current position of vehicle
%     pos = get(All_Vehicles{target_num}, 'AttValue', 'Pos');
    %% Prediction level
    cnt = 1;
    
    while(init < Simul_steps+Np*resolution+1)
        All_Vehicles = Vissim.Net.Vehicles.GetAll;
        target_num = detect_target(All_Vehicles,Target);
        % Adding acceleration to 'Pred_speds(1)'
%         target_num = 34;
        Pred_speds(cnt,1) = get(All_Vehicles{target_num},'AttValue','Acceleration');
        % -> Vehicle's acceleration (m/s^2)
        
        % Adding road slope to 'Pred_speds(2)'
        veh_position    = get(All_Vehicles{target_num}, 'AttValue', 'Pos');
        index = find(degmap(:,1) == ceil(veh_position)-1);
        Pred_speds(cnt,2) = degmap(index,2);
        % slope := tangent of theta ~ theta
        
        % Adding speed value^2 to 'Pred_speds(3)'
        Pred_speds(cnt,3) = (get(All_Vehicles{target_num},'AttValue','Speed')/3.6)^2; 
        % m/s
 
        % second
        target_veh(1) = get(All_Vehicles{target_num},'AttValue','Speed');
        target_veh(2) = veh_position; %Pred_speds(cnt,2);
        lkla = get(All_Vehicles{target_num}, 'AttValue', 'Lane');
        target_veh(3) = str2double(lkla(1));
        target_veh(4) = str2double(lkla(3));
        [f_spacing, lead_speddiff, r_spacing, follow_speddiff] = ...
            detect_spacing(All_Vehicles, target_veh);
        % detect_spacing 함수 검증 요망
        
        % Adding safety distance to the leading vehicle into 'Pred_speds(4)'
        Pred_speds(cnt,4) = veh_position;
        % get(All_Vehicles{target_num},'AttValue','SafDistNet'); 
        
        % Adding delta_t to 'Pred_speds(5)'
        Pred_speds(cnt,5) = delta_t;
        
         % Adding safety distance to the leading vehicle into 'Pred_speds(4)'
        Pred_speds(cnt,6) = f_spacing;
        % get(All_Vehicles{target_num},'AttValue','SafDistNet'); 
        
        % Adding speed difference to the preceding vehicle into 'Pred_speds(6)'
        Pred_speds(cnt,7) = lead_speddiff; %km/h
        % get(All_Vehicles{target_num},'AttValue','SpeedDiff');     
        
        % Adding safety distance to the following vehicle into 'Pred_speds(7)'
        Pred_speds(cnt,8) = r_spacing;
        
        % Adding speed difference to the following vehicle into 'Pred_speds(8)'
        Pred_speds(cnt,9) = follow_speddiff; %km/h
        
        Vissim.Simulation.RunSingleStep;
        
        cnt = cnt + 1;
        init = init + 1;
    end
    %% Simulation stop
    Vissim.Simulation.Stop
    %% Calculating optimized speed profile

    [Opt_speds, total_v, Opt_accs, total_a, Opt_pos, ...
    Physical_pos, Opt_current, Pred_current, ...
    Mot_Eff1, Mot_Eff2, Mot_Rpm1, Mot_Rpm2, Mot_Trq1, Mot_Trq2, ...
    up_buff_v,do_buff_v, up_buff_a, do_buff_a, ...
    violation_v_check,violation_a_check]...
    = SiConvexOpt(Pred_speds, regen_eff,Np);
    
    hist_pred_i = [hist_pred_i; Pred_current(1:Np*resolution)];
    hist_opt_i = [hist_opt_i; Opt_current(1:Np*resolution)];

    hist_pred_v = [hist_pred_v; total_v(1:Np*resolution)];
    hist_opt_v = [hist_opt_v; Opt_speds(1:Np*resolution)];

    hist_pred_a = [hist_pred_a; total_a];
    hist_opt_a = [hist_opt_a; Opt_accs];

    hist_pred_dist = [hist_pred_dist; Physical_pos(1:Np*resolution)];
    hist_opt_dist = [hist_opt_dist; Opt_pos(1:Np*resolution)];

    hist_pred_moteff = [hist_pred_moteff; Mot_Eff1(1:Np*resolution)];
    hist_opt_moteff = [hist_opt_moteff; Mot_Eff2(1:Np*resolution)];
    
    hist_up_v = [hist_up_v;up_buff_v(2:Np*resolution+1)];
    hist_do_v = [hist_do_v;do_buff_v(2:Np*resolution+1)];
    
    hist_up_a = [hist_up_a;up_buff_a(1:Np*resolution)];
    hist_do_a = [hist_do_a;do_buff_a(1:Np*resolution)];
    
    hist_vio_v = [hist_vio_v; violation_v_check];
    hist_vio_a = [hist_vio_a; violation_a_check];
    % pos -> the position of target vehicle in study area 
    %% Initial setting before optimal driving
    init = 1;
    while(init < Fixed_steps)
        Vissim.Simulation.RunSingleStep;
        init = init + 1;
    end
    

    %% Working on optimized driving
    cnt = 1;
    while(init < Simul_steps+Np*resolution)
        All_Vehicles = Vissim.Net.Vehicles.GetAll;
        target_num = detect_target(All_Vehicles,Target);
        Vissim.Simulation.RunSingleStep;
        if hist_opt_v(cnt) < 0
            hist_opt_v(cnt) = 0;
        end
        set(All_Vehicles{target_num},'AttValue','Speed',hist_opt_v(cnt)*3.6); % 13 -> Target Vehicle number
                
        cnt = cnt + 1;
        init = init + 1;
    end
    
    Simul_steps = Simul_steps + Np*resolution;
%     keep_target = get(All_Vehicles{target_num}, 'AttValue', 'Pos');
    disp('distance')
    disp(get(All_Vehicles{target_num}, 'AttValue', 'Pos'))
end
%%
cd('E:\KAIST_TOPS\Study\2_prj_study\VISSIM7\Figure')
figure(1)
plot(hist_opt_dist/1000)
hold on
plot(hist_pred_dist/1000)
hold off
legend('optimal','prediction','Location', 'southeast')
xlabel('Time [second]')
ylabel('Distance [km]')
title('Distance comparison')
disp('dist_difference:')
disp(hist_opt_dist(end)-hist_pred_dist(end))
savefig(['1_Distance_' num2str(regen_eff) '_' num2str(Total_flow) '_Np_' num2str(Np) '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')

figure(2)
plot(cumsum(hist_opt_i)/3600)
hold on
plot(cumsum(hist_pred_i)/3600)
hold off
legend('optimal', 'prediction','Location', 'southeast')
xlabel('Time [second]')
ylabel('Cumulative Current [Ah]')
title('Current comparison')
disp('Save : ')
disp((sum(hist_pred_i)-sum(hist_opt_i))/sum(hist_pred_i))
savefig(['2_Current_' num2str(regen_eff) '_' num2str(Total_flow) '_Np_' num2str(Np)  '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')

figure(3)
plot(hist_opt_v*3.6)
hold on
plot(hist_pred_v*3.6)
plot(hist_up_v*3.6)
plot(hist_do_v*3.6)
hold off
legend('optimal', 'prediction','upper speed','lower speed','Location', 'southeast')
xlabel('Time [second]')
ylabel('Speed [km/h]')
title('Speed comparison')
savefig(['3_Speedhist_' num2str(regen_eff) '_' num2str(Total_flow) '_Np_' num2str(Np)  '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')

figure(4)
plot(hist_opt_moteff)
hold on
plot(hist_pred_moteff)
hold off
legend('optimal','prediction','Location', 'southeast')
title('Motor efficiency comparison')
savefig(['4_Moteff_' num2str(regen_eff) '_' num2str(Total_flow) '_Np_' num2str(Np)  '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')

figure(5)
plot(hist_opt_a)
hold on 
plot(hist_pred_a)
plot(hist_up_a)
plot(hist_do_a)
hold off
legend('optimal','prediction','uppser','lower','Location', 'southeast')
title('Acceration comparison')
savefig(['5_Accelhist_' num2str(regen_eff) '_' num2str(Total_flow) '_Np_' num2str(Np)  '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')
% close all

disp('Predicted efficiency [km/Ah] : ')
disp(hist_pred_dist(end)/sum(hist_pred_i)*3.6)

disp('Optimized efficiency [km/Ah] : ')
disp(hist_opt_dist(end)/sum(hist_opt_i)*3.6)

%%
figure(6)
plot((hist_opt_i))
hold on
plot((hist_pred_i))
hold off
legend('optimal', 'prediction','Location', 'southeast')
xlabel('Time [second]')
ylabel('Current [A]')
title('Current comparison')
% disp('Save : ')
disp((sum(hist_pred_i)-sum(hist_opt_i))/sum(hist_pred_i))
% savefig(['2_Current_' num2str(regen_eff) '_' num2str(Total_flow) '.fig'])
set(gca,'FontSize',14,'fontname','Times New Roman')
