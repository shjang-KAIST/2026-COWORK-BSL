function [opt_v_history, opt_acc_history, Opt_current, cum_opt_sped_distance, ...
    Mot_Eff1, Mot_Rpm1, Mot_Trq1, Pred_current, ...
    Mot_Eff2, Mot_Rpm2, Mot_Trq2, violation_v_check,violation_a_check] = ...
      SiStageII_fixed_2025_new(Pred_speds, Np, total_v,total_a, ...
      up_buff_v, do_buff_v,up_buff_a, do_buff_a, ...
      Mot_par,regen_eff,sys_dist)
% Rewritten to use fmincon instead of casadi.
% Inputs / outputs kept as original. Assumes helper funcs exist:
% SiStageII_approx_slope, SiGet_eff

%% dist-fit
resolution= 1;
f = fit(sys_dist,Pred_speds(1:Np*resolution+1,2),'poly4','Normalize','on'); % curve fitting
deg_fit = coeffvalues(f);

len = size(Pred_speds,1) - 1;

%% vehicle & env params (unchanged)
mass = 1685 + 65; % [kg]
R = 0.33415; 
Af = 2.45;
gear_ratio = 7.981;
mass_factor = 1 + 0.04 * gear_ratio + 0.0025 * gear_ratio^2;
RRC = (0.0066+0.0077)/2;
wind_sped = 2; % m/s
gravity = 9.8;
rho = 1.2;
Cd = 0.288;
k = rho/2*Cd*Af;

%% initialize outputs
opt_acc_history = zeros(len,1);
opt_v_history = zeros(len+1,1);
opt_v_history(1) = total_v(1);

% Predicted current/profile (for comparison)
Pred_current = zeros(len+1,1);
Pred_distance = zeros(len+1,1);
Mot_Eff1 = zeros(len,1);
Mot_Rpm1 = zeros(len,1);
Mot_Trq1 = zeros(len,1);

% Compute Pred_current (as in your original loop)
for i=2:len+1
    Prev_t = Pred_speds(i-1,5);
    Now_v = total_v(i-1);
    N_dist = sys_dist(i-1);
    Now_deg = SiStageII_approx_slope(deg_fit, N_dist, 0);
    F1 = (mass*mass_factor)* total_a(i-1)*R/gear_ratio;
    F2 = k*(Now_v+wind_sped)^2*R/gear_ratio;
    F3 = mass*gravity*sin(Now_deg)*R/gear_ratio;
    F4 = RRC*mass*cos(Now_deg)*gravity*R/gear_ratio;
    Now_rpm = Now_v/R*gear_ratio*30/pi;
    MPC_TorqWO = (F1+F2+F3+F4);
    mot_eff = SiGet_eff(Now_rpm,abs(MPC_TorqWO));
    MPC_Torq = MPC_TorqWO/(mot_eff^sign(MPC_TorqWO));
    % motor linear model params by speed
    if Now_v * 3.6 <= 70
        f_coef_p = Mot_par(1,1); s_coef_p = Mot_par(1,2);
    elseif Now_v * 3.6 <= 100
        f_coef_p = Mot_par(2,1); s_coef_p = Mot_par(2,2);
    else
        f_coef_p = Mot_par(3,1); s_coef_p = Mot_par(3,2);
    end
    mpc_I0 = (MPC_Torq-s_coef_p)/f_coef_p;
    if mpc_I0 >= 0, mpc_I = mpc_I0; else mpc_I = mpc_I0*regen_eff; end
    Pred_current(i-1) = mpc_I * Prev_t;
    Mot_Eff1(i-1) = mot_eff;
    Mot_Rpm1(i-1) = Now_rpm;
    Mot_Trq1(i-1) = MPC_TorqWO;
end

%% prepare optimization variables & bounds
% decision vector: opt_v (length Np) corresponds to opt_v1 in original
% initial guess: use initial_v as in original
initial_v = total_v(2:Np+1);
x0 = initial_v;

lb = do_buff_v(2:2+Np-1); % original used up_buff_v(2:...)
ub = up_buff_v(2:2+Np-1);

% If sizes mismatch, fallback to safe bounds
if length(lb)~=Np || length(ub)~=Np
    lb = zeros(Np,1);
    ub = 40*ones(Np,1);
end

% distance reference: compute predicted distance of original profile
% (Pred_distance building similar to original)
for i = 2:len+1
    Prev_t = Pred_speds(i-1,5);
    Pred_distance(i) = Pred_distance(i-1) + total_v(i-1) * Prev_t + 0.5*total_a(i-1)*Prev_t^2;
end
dist_ref = Pred_distance(end);

% tolerance (meters) for distance difference; adjust if you want
eps_dist = 5; % 기본 5m 허용. 필요시 인자로 노출하세요.

% acceleration limits (from buffers)
% derive acceleration limits from do_buff_a / up_buff_a (they are time-indexed)
a_min = do_buff_a(1:len);
a_max = up_buff_a(1:len);

%% objective: compute total motor current*time for candidate opt_v
mpc_t = Pred_speds(1,5); % time interval used in original within loop

function J = obj_fun(v_decision)
    % v_decision: length Np (speeds at steps 1..Np)
    total_cost = 0;
    temp_v_prev = total_v(1); % start_v
    % Np loop
    for n = 1:Np
        if n==1
            temp_v = temp_v_prev;
            next_v = v_decision(1);
        else
            temp_v = v_decision(n-1);
            if n < Np+1
                next_v = v_decision(n);
            else
                next_v = v_decision(end);
            end
        end
        % slope at current physical distance approximation: use cumulative dist estimate
        % approximate N_dist by (n-1)*mpc_t*temp_v (coarse). Use start=0
        N_dist = (n-1)*mpc_t*temp_v; 
        temp_theta = SiStageII_approx_slope(deg_fit, N_dist, 0);
        temp_mpc_rpm = temp_v/R*gear_ratio*30/pi;
        % torque components
        F1 = (mass*mass_factor)*(next_v - temp_v)/mpc_t*R/gear_ratio;
        F2 = k*(temp_v+wind_sped)^2*R/gear_ratio;
        F3 = mass*gravity*sin(temp_theta)*R/gear_ratio;
        F4 = RRC*mass*cos(temp_theta)*gravity*R/gear_ratio;
        MPC_TorqWO = (F1+F2+F3+F4);
        mot_eff = SiGet_eff(temp_mpc_rpm,abs(MPC_TorqWO));
        % avoid sign issues
        if abs(MPC_TorqWO) < 1e-9
            MPC_Torq = 0;
        else
            MPC_Torq = MPC_TorqWO/(mot_eff^(MPC_TorqWO/abs(MPC_TorqWO)));
        end
        % motor params by speed
        if temp_v * 3.6 <= 70
            f_coef_p = Mot_par(1,1); s_coef_p = Mot_par(1,2);
        elseif temp_v * 3.6 <= 100
            f_coef_p = Mot_par(2,1); s_coef_p = Mot_par(2,2);
        else
            f_coef_p = Mot_par(3,1); s_coef_p = Mot_par(3,2);
        end
        mpc_I0 = (MPC_Torq - s_coef_p)/f_coef_p;
        if mpc_I0 >= 0
            mpc_I = mpc_I0;
        else
            mpc_I = mpc_I0 * regen_eff;
        end
        total_cost = total_cost + mpc_I * mpc_t;
    end
    J = total_cost;
end

%% nonlinear constraints: distance closeness & accel limits
function [c, ceq] = nonlcon(v_decision)
    % compute opt trajectory distances and accelerations
    % v_history: start_v, then v_decision(1..Np)
    start_v = total_v(1);
    v_hist = [start_v; v_decision(:)]; % length Np+1
    % compute cumulative distance
    cumdist = zeros(Np+1,1);
    for ii=2:Np+1
        dt_i = Pred_speds(ii-1,5);
        cumdist(ii) = cumdist(ii-1) + v_hist(ii-1)*dt_i + 0.5 * ((v_hist(ii)-v_hist(ii-1))/dt_i) * dt_i^2;
        % simplified: v_prev*dt + 0.5*a*dt^2
    end
    dist_opt = cumdist(end);
    % distance constraint: allow |dist_opt - dist_ref| <= eps_dist
    c1 = abs(dist_opt - dist_ref) - eps_dist; % <=0 OK
    % acceleration constraints (inequalities): for each interval acceleration within [a_min,a_max]
    acc = zeros(Np,1);
    for ii=1:Np
        dt_i = Pred_speds(ii,5);
        acc(ii) = (v_hist(ii+1)-v_hist(ii))/dt_i;
    end
    % build c such that c <= 0 satisfied: c_acc_pos = acc - a_max <=0, c_acc_neg = a_min - acc <=0
    c_acc_pos = acc - a_max(:);
    c_acc_neg = a_min(:) - acc;
    c = [c1; c_acc_pos; c_acc_neg];
    ceq = []; % we use inequality for distance; if you prefer equality, put it here
end

%% fmincon options
opts = optimoptions('fmincon','Display','iter','Algorithm','sqp','MaxFunctionEvaluations',3e5,'MaxIterations',2000);

% call solver
problem.objective = @(x)obj_fun(x);
problem.x0 = x0;
problem.lb = lb;
problem.ub = ub;
problem.nonlcon = @(x)nonlcon(x);
problem.solver = 'fmincon';
problem.options = opts;

[xopt, fval, exitflag, output] = fmincon(problem);

% assemble opt_v_history (start + opt sequence)
for idx = 1:Np
    opt_v_history(idx+1) = xopt(idx);
end

% compute opt accelerations
for iter = 2:Np + 1
    opt_sol_iter= opt_v_history(iter);
    cur_sped = opt_v_history(iter-1);
    next_sped = opt_sol_iter;
    dt_i = Pred_speds(iter-1,5);
    opt_acc_history(iter-1)= (next_sped - cur_sped)/dt_i;
end

%% Evaluate optimal profile quantities (currents, torque, etc.)
temp1 = opt_v_history;
temp2 = opt_acc_history;
temp30 = zeros(len+1,1);
temp3 = zeros(len+1,1);
temp4 = zeros(len+1,1);
Mot_Eff2 = zeros(len+1,1);
Mot_Rpm2 = zeros(len+1,1);
Mot_Trq2 = zeros(len+1,1);

violation_v_check = 0;
violation_a_check = 0;

% compute cumulative optimized distance timeline (temp4) and Pred_distance (already computed earlier)
for i = 2 : len + 1
    Now_t = Pred_speds(i,5);
    temp4(i) = temp4(i-1) + temp1(i-1)*Now_t + 0.5*temp2(i-1)*Now_t^2;
end

% compute motor quantities for optimized profile
for i=2:len+1
    Prev_t = Pred_speds(i-1,5);
    Now_v = temp1(i-1);
    N_dist = temp4(i-1);
    Now_deg = SiStageII_approx_slope(deg_fit, N_dist,0);
    F1 = (mass*mass_factor)* temp2(i-1)*R/gear_ratio;
    F2 = k*(Now_v+wind_sped)^2*R/gear_ratio;
    F3 = mass*gravity*sin(Now_deg)*R/gear_ratio;
    F4 = RRC*mass*cos(Now_deg)*gravity*R/gear_ratio;
    Now_rpm = Now_v/R*gear_ratio*30/pi;
    MPC_TorqWO = (F1+F2+F3+F4);
    mot_eff = SiGet_eff(Now_rpm,abs(MPC_TorqWO));
    MPC_Torq = MPC_TorqWO/(mot_eff^sign(MPC_TorqWO));
    if Now_v * 3.6 <= 70
        f_coef_p = Mot_par(1,1); s_coef_p = Mot_par(1,2);
    elseif Now_v * 3.6 <= 100
        f_coef_p = Mot_par(2,1); s_coef_p = Mot_par(2,2);
    else
        f_coef_p = Mot_par(3,1); s_coef_p = Mot_par(3,2);
    end
    mpc_I0 = (MPC_Torq-s_coef_p)/f_coef_p;
    if mpc_I0 >= 0 
        mpc_I = mpc_I0;
    else
        mpc_I = mpc_I0*regen_eff;
    end
    temp30(i-1) = (mpc_I0)*Prev_t;
    temp3(i-1) = (mpc_I)*Prev_t;
    Mot_Eff2(i-1) = mot_eff;
    Mot_Rpm2(i-1) = Now_rpm;
    Mot_Trq2(i-1) = MPC_TorqWO;
    % violation checks against buffers
    if temp1(i) < do_buff_v(i) || temp1(i) > up_buff_v(i)
        violation_v_check = violation_v_check + 1;
    end
    if temp2(i-1) < do_buff_a(i-1) || temp2(i-1) > up_buff_a(i-1)
        violation_a_check = violation_a_check + 1;
    end
end

Opt_current = temp3;
cum_opt_sped_distance = temp4;

end
