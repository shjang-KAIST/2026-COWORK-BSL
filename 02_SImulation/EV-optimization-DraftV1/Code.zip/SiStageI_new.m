function [up_buff_v,do_buff_v, up_buff_a, do_buff_a, total_v, ...
    total_a] = SiStageI_new(Pred_speds,Np)
%% Torq variables
len = size(Pred_speds,1) - 1;

%% Actual acceleration and speed trajectory
total_a = zeros(len,1);
for i=1:len
    if Pred_speds(i+1,4) - Pred_speds(i,4) ~= 0
        total_a(i) = (Pred_speds(i+1,3)-Pred_speds(i,3))...
            /2/(Pred_speds(i+1,4)-Pred_speds(i,4));
    else
        total_a(i) = 0;
    end
end

total_v = sqrt(Pred_speds(:,3)); % size 6 by 1


%% buffer bound
% Spacing history of target vehicle
% 0 -> No vehicle
% Pred_speds(i,4);
sample_time = Pred_speds(1,5);
% safety_margin_up = sqrt(Pred_speds(:,3))*3.6;
up_en_dist =  Pred_speds(1:Np,6); % - safety_margin_up; (unit : m)
up_en_dist(up_en_dist<10) = 10;

% safety_margin_do = sqrt(Pred_speds(:,3))*3.6 - Pred_speds(:,9);
do_en_dist =  Pred_speds(1:Np,8); % - safety_margin_do; (unit : m)
do_en_dist(do_en_dist<10) = 10;

up_buff_a = 2*(-Pred_speds(1:Np,7)/3.6*Np + up_en_dist)/Np^2;
up_buff_a = max(up_buff_a, Pred_speds(2:Np+1,1));
up_buff_a(up_buff_a>3.65) = 3.65; % the maximum accelertaion 3.65m/s^2


do_buff_a = 2*(-Pred_speds(1:Np,9)/3.6*Np - do_en_dist)/Np^2;
do_buff_a = min(do_buff_a, Pred_speds(2:Np+1,1));
do_buff_a(do_buff_a<-3.65) = -3.65;

up_buff_v = total_v(1);
up_buff_v = [up_buff_v; total_v(1:Np) + up_buff_a*sample_time]; % 
up_buff_v(up_buff_v<0) = 0.2;

do_buff_v = total_v(1);
do_buff_v = [do_buff_v; total_v(1:Np) + do_buff_a*sample_time]; % 
do_buff_v(do_buff_v < 0 ) = 0;

up_buff_a(up_buff_a < do_buff_a) = do_buff_a(up_buff_a < do_buff_a);
%%
% figure(10)
% plot(total_v)
% hold on
% plot(up_buff_v,'-.')
% plot(do_buff_v,'-.')
% hold off
% legend('pred speed','up buff','do buff')
% title('Stage I speed boundary')
% 
% figure(11)
% plot(total_a)
% hold on
% plot(up_buff_a,'-.')
% plot(do_buff_a,'-.')
% hold off
% legend('pred acc','up acc','do acc')
% title('Stage I acc boundary')
